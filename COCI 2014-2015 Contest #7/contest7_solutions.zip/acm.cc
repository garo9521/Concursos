#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int a[3][150 * 1000];
int memo[150 * 1001][3]; 
int n;
const int INF = 1000 * 1000 * 1000;

int dp(int k, int koji) {
    int &ref = memo[k][koji];
    if (ref != -1) return ref;
    if (k == n)
        return ref = (koji == 2 ? 0 : INF);
    ref = a[koji][k] + dp(k + 1, koji);
    if (koji != 2)
        ref = min(ref, a[koji + 1][k] + dp(k + 1, koji + 1));
    return ref;
}

int main() {
    scanf("%d", &n);
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < n; ++j)
            scanf("%d", &a[i][j]);
    memset(memo, -1, sizeof(memo));
    printf("%d\n", a[0][0] + dp(1, 0));
}
